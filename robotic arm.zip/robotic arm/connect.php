<?php


$conn = mysqli_connect('localhost','root','','robot_arm_control');


if(isset($_POST['save'])){

$gripper = $_POST['gripper'];
$wrist1 = $_POST['wrist1'];
$wrist2 = $_POST['wrist2'];
$elbow = $_POST['elbow'];
$shoulder = $_POST['shoulder'];
$base = $_POST['base'];

$sql = mysqli_query($conn,"INSERT INTO robot_arm_control(base,shoulder,elbow,wrist1,wrist2,gripper) VALUES ('$base', '$shoulder', '$elbow', '$wrist1', '$wrist2',$gripper)");


if($sql){	
	echo "The data has been saved !";
}

else{
	
	echo "nothing was inserted into table.";
}

}

if(isset($_POST['run'])){

$sql = mysqli_query($conn,"UPDATE robot_arm_control SET status='on' WHERE base='$base' AND shoulder='$shoulder' AND elbow='$elbow' AND wrist1='$wrist1' AND wrist2='$wrist2' AND gripper='$gripper'");	
	
if($sql){	
	
	echo"in progress now...";

}

else{
	
	echo"Not working, there is an error.";
}

}	


mysqli_close($conn);


$conn2 = mysqli_connect('localhost','root','','robot_arm_control');

if(isset($_POST['left'])){


$sql = mysqli_query($conn2,"INSERT INTO robot_base(direction) VALUES ('L')");


if(!$sql){	

	echo "nothing was inserted into table.";

}
}

if(isset($_POST['right'])){


$sql = mysqli_query($conn2,"INSERT INTO robot_base(direction) VALUES ('R')");


if(!$sql){	

	echo "nothing was inserted into table.";

}
}

if(isset($_POST['forward'])){


$sql = mysqli_query($conn2,"INSERT INTO robot_base(direction) VALUES ('F')");


if(!$sql){	

	echo "nothing was inserted into table.";

}
}

if(isset($_POST['backward'])){


$sql = mysqli_query($conn2,"INSERT INTO robot_base(direction) VALUES ('B')");


if(!$sql){	

	echo "nothing was inserted into table.";

}
}	


if(isset($_POST['stop'])){

echo "You stopped the robot from moving.";

}

mysqli_close($conn2);


?>
